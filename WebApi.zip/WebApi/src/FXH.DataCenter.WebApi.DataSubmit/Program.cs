﻿#region 版本信息
/*
 * $Author: zsuxiong, $Revision: 1, $Date: 2018年5月18日
 * $History: None
*/
#endregion 版本信息


using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Serilog;
using Serilog.Events;

namespace FXH.DataCenter.WebApi.DataSubmit
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            #region 初始化 

            var config = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                   .AddJsonFile("hosting.json")
                .AddJsonFile("appsettings.json")
                .AddJsonFile($"appsettings.{Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")}.json", optional: true)
                .AddEnvironmentVariables()
                .AddCommandLine(args)
                .Build();
            //Debug模式会直接写到控制台，发布模式写到文件
            Log.Logger = new LoggerConfiguration()
#if DEBUG

                .MinimumLevel.Debug()
                .MinimumLevel.Override("Microsoft", LogEventLevel.Debug)
                .Enrich.FromLogContext()
                .WriteTo.ColoredConsole()
#else

                                .ReadFrom.Configuration(config)
#endif
                .CreateLogger();
            #endregion

            CreateWebHostBuilder(config, args).Build().Run();
        }

        public static IWebHostBuilder CreateWebHostBuilder(IConfiguration config, string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .UseConfiguration(config)
                .UseStartup<Startup>();
    }
     
}
