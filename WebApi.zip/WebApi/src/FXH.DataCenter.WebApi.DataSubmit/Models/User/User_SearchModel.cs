﻿using FXH.DataCenter.WebApi.DataSubmit.Models.Const;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace FXH.DataCenter.WebApi.DataSubmit.Models.User
{
    [Table(TableNameConst.USER_SEARCHMODEL)]  
    public class User_SearchModel
    {
        #region 属性

        /// <summary>自增</summary>
        [DisplayName("自增")]
        public Int64 LogID { get; set; }
        /// <summary>默认为0	用户ID</summary>
        [DisplayName("默认为0	用户ID")]
        public Int32 UserID { get; set; }
        /// <summary>浏览器客户端cookie 存放的区分唯一标记的uid 或是app的uid</summary>
        [DisplayName("浏览器客户端cookie存放的区分唯一标记的uid或是app的uid")]
        public String UID { get; set; }

        /// <summary>user agent</summary>
        [DisplayName("useragent")]
        public String UserAgent { get; set; }
        /// <summary>上一个搜索关键词</summary>
        [DisplayName("上一个搜索关键词")]

        public String LastKeyWord { get; set; }
        /// <summary>搜索关键词</summary>
        [DisplayName("搜索关键词")]

        public String KeyWord { get; set; }

        /// <summary>虚拟币代码</summary>
        [DisplayName("虚拟币代码")]

        public String CoinCode { get; set; }

        /// <summary>交易所代码</summary>
        [DisplayName("交易所代码")]

        public String SiteCode { get; set; }

        /// <summary>市场（交易对2）</summary>
        [DisplayName("市场交易对2")]

        public String Market { get; set; }

        /// <summary>用户的ip地址</summary>
        [DisplayName("用户的ip地址")]

        public String IP { get; set; }

        /// <summary>点击时间</summary>
        [DisplayName("点击时间")]

        public DateTime LogTime { get; set; }

        /// <summary>应用id</summary>
        [DisplayName("应用id")]

        public Int16 AppID { get; set; }

        /// <summary>操作系统类型（字符串表示，如：windows 10,android）</summary>
        [DisplayName("操作系统类型字符串表示，如：windows10,android")]

        public String OsType { get; set; }

        /// <summary>浏览器类型</summary>
        [DisplayName("浏览器类型")]

        public String BrowserType { get; set; }

        /// <summary>应用的版本号</summary>
        [DisplayName("应用的版本号")] 
        public String AppVer { get; set; }

        #endregion
    }
}
