﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FXH.DataCenter.WebApi.DataSubmit.Models.Const
{
    /// <summary>
    /// 表名常量
    /// </summary>
    public class TableNameConst
    {
        /// <summary>
        /// 用户点击日志表
        /// </summary>
        public const string USER_CLICKMODEL = "log_user_click";

        /// <summary>
        /// 用户搜索日志表
        /// </summary>
        public const string USER_SEARCHMODEL = "log_user_search";

    }
}
