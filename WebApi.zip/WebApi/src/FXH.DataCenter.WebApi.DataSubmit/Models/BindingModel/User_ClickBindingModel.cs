﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FXH.DataCenter.WebApi.DataSubmit.Models
{
    /// <summary>
    /// 用户点击日志表
    /// </summary>
    public class User_ClickBindingModel
    {
        #region 属性

        /// <summary>
        /// 默认为0	用户ID
        /// </summary>
        [Required]     
        [Description("默认为0	用户ID")] 
        public Int32 UserID { get; set; }

        /// <summary>
        /// 浏览器客户端cookie 存放的区分唯一标记的uid 或是app的uid
        /// </summary>
        [Required] 
        [Description("浏览器客户端cookie存放的区分唯一标记的uid或是app的uid")] 
        public String UID { get; set; }
        /// <summary>
        /// user agent
        /// </summary>
        [Description("useragent")] 
        public String UserAgent { get; set; }
        /// <summary>
        /// Refer的url链接
        /// </summary>
        [Description("Refer的url链接")] 
        public String Referer { get; set; }

        /// <summary>
        /// 点击的url链接
        /// </summary>
        [Required] 
        [Description("点击的url链接")]
        public String TargetUrl { get; set; }


        /// <summary>
        /// 应用id
        /// </summary>
        [Description("应用id")] 
        public Int16 AppID { get; set; }

        /// <summary>
        /// 操作系统类型（字符串表示，如：windows 10,android）
        /// </summary>
        [Description("操作系统类型字符串表示，如：windows10,android")] 
        public String OsType { get; set; }

        /// <summary>
        /// 浏览器类型
        /// </summary>
        [Description("浏览器类型")] 
        public String BrowserType { get; set; }

        /// <summary>
        /// 应用的版本号
        /// </summary>
        [Description("应用的版本号")] 
        public String AppVer { get; set; }

        #endregion
    }
}
