﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks; 
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using NSwag.Annotations; 
using FXH.DataCenter.WebApi.DataSubmit.Interfaces;
using FXH.DataCenter.WebApi.DataSubmit.Models;
using System.Globalization; 
using FXH.DataCenter.WebApi.DataSubmit.Models.BindingModel;
using FXH.DataCenter.WebApi.DataSubmit.Models.User;
using FXH.Common.Logger;
using FXH.Web.Extensions.Model.Api;
using FXH.DapperService; 
using FXH.Web.Extensions.Http;
namespace FXH.DataCenter.WebApi.DataSubmit.Controllers
{
    /// <inheritdoc />
    /// <summary>
    /// 用户搜索日志
    /// </summary>
    [Route("api/log/usersearch/")]
    [Authorize]
    public class UserSearchController : Controller
    { 
        private readonly DapperRepository _dapperRepository;
        private readonly IUserLogService _userLogService;

        
        public UserSearchController(DapperRepository dapperRepository, IUserLogService  userLogService )
        {
            //按需从入口处获取DI的DBContext
            _dapperRepository = dapperRepository; 
            _userLogService = userLogService;
        }

      
        [HttpPost("add")]
        [AllowAnonymous]
        [SwaggerResponse(ApiResponseCode.OK, typeof(SucessDetail), Description = "操作成功")]
        [SwaggerResponse(ApiResponseCode.ERROR, typeof(ErrorDetail), Description = "操作失败，详情见返回对象")] 
        public async Task<IActionResult> Add([FromBody] User_SearchBindingModel bindingModel)
        {
            try
            {
                User_SearchModel model = new User_SearchModel();
                model.AppID = bindingModel.AppID;
                model.AppVer = bindingModel.AppVer;
                model.BrowserType = bindingModel.BrowserType;
                model.LogTime = DateTime.Now.ToUniversalTime();
                model.CoinCode = bindingModel.CoinCode;
                model.LastKeyWord = bindingModel.LastKeyWord;
                model.KeyWord = bindingModel.KeyWord;
                model.UID = bindingModel.UID;
                model.UserAgent = bindingModel.UserAgent;
                model.Market = bindingModel.Market;
                model.OsType = bindingModel.OsType;
                model.SiteCode = bindingModel.SiteCode;
                model.UserID = bindingModel.UserID;
                model.IP = HttpContext.GetIPAddress();

                bool isSuccess= await  _userLogService.AddUserSearch(model);
                if(isSuccess)
                {
                    return Json(new SucessDetail() { Code = ApiResponseCode.OK, Msg = "OK" });
                }
                else
                {
                    return Json(new ErrorDetail() { Code = ApiResponseCode.ERROR,  Error = "Insert Error" });
                }
               
            }
            catch (Exception ex)
            {
                LogExtension.LogError(ex,"insert usersearch log error");
                return Json(new ErrorDetail() { Code = ApiResponseCode.SERVER_ERROR, Error = "Server Error" });

            }
        }

       


    }
}
