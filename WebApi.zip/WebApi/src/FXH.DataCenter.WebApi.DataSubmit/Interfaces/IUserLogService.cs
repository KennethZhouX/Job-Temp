﻿using FXH.DataCenter.WebApi.DataSubmit.Models;
using FXH.DataCenter.WebApi.DataSubmit.Models.User;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FXH.DataCenter.WebApi.DataSubmit.Interfaces
{
    public interface IUserLogService
    {
        /// <summary>
        /// 新增一条日志
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
          Task<bool> AddUserClick(User_ClickModel model);

        /// <summary>
        /// 新增一条用户搜索日志
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        Task<bool> AddUserSearch(User_SearchModel model);
    }
}
