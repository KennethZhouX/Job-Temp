﻿using FXH.DataCenter.WebApi.DataSubmit.Interfaces;
using FXH.DataCenter.WebApi.DataSubmit.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Microsoft.Extensions.DependencyInjection
{
    /// <summary>
    /// 将常用的服务集中写在这里，然后在StartUp里的ConfigureServices里通过service.AddApiService()将这些服务一起注入到容器里。
    /// </summary>
    public static class BQIServiceExtensions
    {
        /// <summary>
        /// 网站后台的service
        /// </summary>
        /// <param name="services"></param>
        /// <returns></returns>
        public static IServiceCollection AddApiService(this IServiceCollection services)
        {
         
            services.AddScoped<IUserLogService, UserLogService>(); 
            return services;
        }
 
    }
}