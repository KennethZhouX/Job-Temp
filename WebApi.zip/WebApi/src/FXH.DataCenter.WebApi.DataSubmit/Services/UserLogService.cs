﻿using FXH.DataCenter.WebApi.DataSubmit.Models; 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Dapper.Contrib.Extensions;
using FXH.DataCenter.WebApi.DataSubmit.Interfaces;
using Microsoft.AspNetCore.Http;
using FXH.DataCenter.WebApi.DataSubmit.Models.User;
using FXH.DapperService; 
using FXH.Web.Extensions.Http;
namespace FXH.DataCenter.WebApi.DataSubmit.Services
{
    public class UserLogService: IUserLogService
    { 
         private readonly DapperRepository _dbContext;
        public UserLogService(DapperRepository dbContext)
        {
            _dbContext = dbContext;
        }
        /// <summary>
        /// 新增一条用户点击日志
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<bool> AddUserClick(User_ClickModel model)
        {

            int sucNum = 0;
            using (var connnection = _dbContext.Connection)
            {
                sucNum= await connnection.InsertAsync<User_ClickModel>(model) ;
            }
            return sucNum>0;
        }
        /// <summary>
        /// 新增一条用户搜索的日志
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<bool> AddUserSearch(User_SearchModel model)
        {

            int sucNum = 0;
            using (var connnection = _dbContext.Connection)
            {
                sucNum = await connnection.InsertAsync<User_SearchModel>(model);
            }
            return sucNum > 0;
        }
    }
}
