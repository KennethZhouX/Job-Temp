﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FXH.DataCenter.WebApi.Models.Consts
{
   public  class TableNameConst
    {
        #region 虚拟币简称别名表
        /// <summary>
        /// 虚拟币简称别名表
        /// </summary>
        public const string BASE_COINSYMBOL_ALIAS = "base_coinsymbol_alias";
        #endregion
    }
}
